package ru.stepan1411.chat_images.client.screen;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class OverlayScreen extends class_437 {

    protected final class_437 parent;

    protected OverlayScreen(class_2561 title, class_437 parent) {
        super(title);
        this.parent = parent;
    }

    @Override
    public void method_25419() {
        if (field_22787 != null && parent != null) {
            field_22787.method_1507(parent);
        } else {
            super.method_25419();
        }
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        actualRender(guiGraphics, mouseX, mouseY, delta);
        super.method_25394(guiGraphics, mouseX, mouseY, delta);
    }

    protected void actualRender(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        guiGraphics.method_25294(0, 0, field_22789, field_22790, 0x80000000);
    }

}
