package ru.stepan1411.chat_images.client.screen;

import org.lwjgl.glfw.GLFW;
import ru.stepan1411.chat_images.client.ImageChatStorage;

import java.util.UUID;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class FullScreenImageViewerScreen extends OverlayScreen {

    private final UUID imageId;
    private double zoom = 1.0;
    private double offsetX = 0;
    private double offsetY = 0;
    private boolean dragging = false;
    private double dragStartX;
    private double dragStartY;
    private double dragOffsetX;
    private double dragOffsetY;
    private long handCursor;
    private boolean cursorIsHand;

    public FullScreenImageViewerScreen(class_437 parent, UUID imageId) {
        super(class_2561.method_43471("chat_images.viewer"), parent);
        this.imageId = imageId;
        this.handCursor = GLFW.glfwCreateStandardCursor(GLFW.GLFW_POINTING_HAND_CURSOR);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean isHovered) {
        if (event.method_74245() == 0) {
            dragging = true;
            dragStartX = event.comp_4798();
            dragStartY = event.comp_4799();
            dragOffsetX = offsetX;
            dragOffsetY = offsetY;
            return true;
        }
        if (event.method_74245() == 1) {
            method_25419();
            return true;
        }
        return super.method_25402(event, isHovered);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        dragging = false;
        return super.method_25406(event);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (dragging && event.method_74245() == 0) {
            offsetX = dragOffsetX + (event.comp_4798() - dragStartX);
            offsetY = dragOffsetY + (event.comp_4799() - dragStartY);
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        double factor = scrollY > 0 ? 1.1 : 1.0 / 1.1;
        double newZoom = Math.max(0.025, Math.min(zoom * factor, 40.0));
        if (newZoom == zoom) return true;

        var nativeImage = ImageChatStorage.getTexture(imageId).method_4525();
        if (nativeImage == null) return true;

        int frameCount = ImageChatStorage.getFrameCount(imageId);
        int dispW, dispH;
        if (frameCount > 1) {
            dispW = ImageChatStorage.getFrameWidth(imageId);
            dispH = ImageChatStorage.getFrameHeight(imageId);
        } else {
            dispW = nativeImage.method_4307();
            dispH = nativeImage.method_4323();
        }
        double fitScale = Math.min((double) field_22789 / dispW, (double) field_22790 / dispH) * 0.85;
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;

        double fracX = (mouseX - (cx - dispW * fitScale * zoom / 2 + offsetX)) / (dispW * fitScale * zoom);
        double fracY = (mouseY - (cy - dispH * fitScale * zoom / 2 + offsetY)) / (dispH * fitScale * zoom);

        zoom = newZoom;

        offsetX = mouseX - cx + dispW * fitScale * zoom * (0.5 - fracX);
        offsetY = mouseY - cy + dispH * fitScale * zoom * (0.5 - fracY);

        return true;
    }

    @Override
    public void method_25419() {
        if (cursorIsHand) {
            GLFW.glfwSetCursor(class_310.method_1551().method_22683().method_4490(), 0);
            cursorIsHand = false;
        }
        if (handCursor != 0) {
            GLFW.glfwDestroyCursor(handCursor);
            handCursor = 0;
        }
        super.method_25419();
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (event.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            method_25419();
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    protected void actualRender(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        super.actualRender(guiGraphics, mouseX, mouseY, delta);

        class_2960 texId = ImageChatStorage.getTextureId(imageId);
        if (texId == null) {
            guiGraphics.method_27535(field_22793, class_2561.method_43471("chat_images.image_removed"),
                    field_22789 / 2 - field_22793.method_27525(class_2561.method_43471("chat_images.image_removed")) / 2,
                    field_22790 / 2, 0xFFFF5555);
            return;
        }

        var nativeImage = ImageChatStorage.getTexture(imageId).method_4525();
        if (nativeImage == null) {
            guiGraphics.method_27535(field_22793, class_2561.method_43471("chat_images.image_removed"),
                    field_22789 / 2 - field_22793.method_27525(class_2561.method_43471("chat_images.image_removed")) / 2,
                    field_22790 / 2, 0xFFFF5555);
            return;
        }

        int frameCount = ImageChatStorage.getFrameCount(imageId);
        int dispW, dispH;
        float vMin = 0.0f, vMax = 1.0f;
        if (frameCount > 1) {
            dispW = ImageChatStorage.getFrameWidth(imageId);
            dispH = ImageChatStorage.getFrameHeight(imageId);
            int currentFrame = ImageChatStorage.getCurrentFrame(imageId);
            vMin = (float) currentFrame / frameCount;
            vMax = (float) (currentFrame + 1) / frameCount;
        } else {
            dispW = nativeImage.method_4307();
            dispH = nativeImage.method_4323();
        }

        double fitScale = Math.min((double) field_22789 / dispW, (double) field_22790 / dispH) * 0.85;

        int imgW = (int) (dispW * fitScale * zoom);
        int imgH = (int) (dispH * fitScale * zoom);

        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;

        int x = centerX - imgW / 2 + (int) offsetX;
        int y = centerY - imgH / 2 + (int) offsetY;

        guiGraphics.method_70845(texId, x, y, x + imgW, y + imgH, 0.0f, 1.0f, vMin, vMax);

        String info = dispW + "x" + dispH + "  " + String.format("%.0f", zoom * 100) + "%";
        guiGraphics.method_25303(field_22793, info, 10, field_22790 - 20, 0xFFFFFFFF);

        boolean overImage = mouseX >= x && mouseX <= x + imgW && mouseY >= y && mouseY <= y + imgH;
        boolean wantHand = overImage || dragging;
        if (wantHand != cursorIsHand) {
            cursorIsHand = wantHand;
            long window = class_310.method_1551().method_22683().method_4490();
            GLFW.glfwSetCursor(window, wantHand ? handCursor : 0);
        }
    }

}
