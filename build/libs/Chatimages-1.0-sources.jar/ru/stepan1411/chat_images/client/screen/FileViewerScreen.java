package ru.stepan1411.chat_images.client.screen;

import ru.stepan1411.chat_images.Chat_images;
import ru.stepan1411.chat_images.client.FileChatStorage;
import ru.stepan1411.chat_images.client.FileUtil;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class FileViewerScreen extends OverlayScreen {

    private final UUID fileId;
    private final FileChatStorage.FileEntry entry;

    public FileViewerScreen(class_437 parent, UUID fileId) {
        super(class_2561.method_43470("File Viewer"), parent);
        this.fileId = fileId;
        this.entry = FileChatStorage.get(fileId);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean isHovered) {
        if (event.method_74245() == 1) {
            method_25419();
            return true;
        }

        int bx = field_22789 / 2 - 60;
        int by = field_22790 / 2 + 30;
        int bw = 120;
        int bh = 20;

        if (event.method_74245() == 0 && event.comp_4798() >= bx && event.comp_4798() <= bx + bw && event.comp_4799() >= by && event.comp_4799() <= by + bh) {
            openExternally();
            return true;
        }

        return super.method_25402(event, isHovered);
    }

    private void openExternally() {
        if (entry == null) return;
        try {
            String ext = FileUtil.getExtension(entry.fileName());
            Path tempDir = Files.createTempDirectory("chatimages_");
            File tempFile = tempDir.resolve(entry.fileName()).toFile();
            tempFile.deleteOnExit();
            tempDir.toFile().deleteOnExit();
            Files.write(tempFile.toPath(), entry.data());
            Desktop.getDesktop().open(tempFile);
        } catch (IOException e) {
            Chat_images.LOGGER.error("Failed to open file externally", e);
        }
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (event.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            method_25419();
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    protected void actualRender(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        super.actualRender(guiGraphics, mouseX, mouseY, delta);

        if (entry == null) {
            guiGraphics.method_27535(field_22793, class_2561.method_43470("File not found"),
                    field_22789 / 2 - field_22793.method_1727("File not found") / 2, field_22790 / 2, 0xFFFF5555);
            return;
        }

        int cx = field_22789 / 2;
        int cy = field_22790 / 2 - 30;

        guiGraphics.method_27535(field_22793, class_2561.method_43470("§l" + entry.fileName()), cx - field_22793.method_1727(entry.fileName()) / 2, cy, 0xFFFFFFFF);
        guiGraphics.method_27535(field_22793, class_2561.method_43470("Sender: " + entry.senderName()), cx - field_22793.method_1727("Sender: " + entry.senderName()) / 2, cy + 15, 0xFFAAAAAA);
        guiGraphics.method_27535(field_22793, class_2561.method_43470("Size: " + FileUtil.formatFileSize(entry.data().length)), cx - field_22793.method_1727("Size: " + FileUtil.formatFileSize(entry.data().length)) / 2, cy + 30, 0xFFAAAAAA);

        int bx = cx - 60;
        int by = cy + 60;
        boolean hovered = mouseX >= bx && mouseX <= bx + 120 && mouseY >= by && mouseY <= by + 20;
        guiGraphics.method_25294(bx, by, bx + 120, by + 20, hovered ? 0xFF555555 : 0xFF333333);
        guiGraphics.method_27535(field_22793, class_2561.method_43470("Open externally"), cx - field_22793.method_1727("Open externally") / 2, by + 6, 0xFFFFFFFF);
    }
}
