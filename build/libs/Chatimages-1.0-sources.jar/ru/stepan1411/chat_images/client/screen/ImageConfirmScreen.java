package ru.stepan1411.chat_images.client.screen;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7591;
import net.minecraft.class_7919;
import net.minecraft.class_8666;
import ru.stepan1411.chat_images.Chat_images;
import ru.stepan1411.chat_images.client.FileChatStorage;
import ru.stepan1411.chat_images.client.FileUtil;
import ru.stepan1411.chat_images.client.ImageChatStorage;
import ru.stepan1411.chat_images.networking.ImageDataC2SPayload;
import ru.stepan1411.chat_images.networking.ImageEndC2SPayload;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.UUID;

public class ImageConfirmScreen extends OverlayScreen {

    private static final class_8666 CONFIRM_SPRITES = new class_8666(
            class_2960.method_60655(Chat_images.MOD_ID, "confirm"),
            class_2960.method_60655(Chat_images.MOD_ID, "confirm")
    );
    private static final class_8666 CANCEL_SPRITES = new class_8666(
            class_2960.method_60655(Chat_images.MOD_ID, "cancel"),
            class_2960.method_60655(Chat_images.MOD_ID, "cancel")
    );

    private final byte[] sendBytes;
    private final byte[] previewBytes;
    private final String fileName;
    private final boolean isImage;
    private class_1043 previewTexture;
    private class_2960 previewId;
    private int imageWidth;
    private int imageHeight;
    private double zoom = 1.0;
    private double offsetX = 0;
    private double offsetY = 0;
    private boolean dragging = false;
    private double dragStartX;
    private double dragStartY;
    private double dragOffsetX;
    private double dragOffsetY;
    private class_344 confirmButton;
    private class_344 cancelButton;
    private UUID previewUuid;
    private boolean confirmed = false;

    public ImageConfirmScreen(class_437 parent, byte[] sendBytes, byte[] previewBytes, String fileName, boolean isImage) {
        super(class_2561.method_43471("chat_images.confirm"), parent);
        this.sendBytes = sendBytes;
        this.previewBytes = previewBytes;
        this.fileName = fileName;
        this.isImage = isImage;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (isImage) loadPreview();

        int cx = field_22789 / 2;
        int cy = field_22790 / 2;

        confirmButton = method_37063(new class_344(
                cx - 60,
                cy + 60,
                20, 20,
                CONFIRM_SPRITES,
                button -> sendFile(),
                class_5244.field_39003
        ));
        confirmButton.method_47400(class_7919.method_47407(class_2561.method_43471("chat_images.send")));

        cancelButton = method_37063(new class_344(
                cx + 40,
                cy + 60,
                20, 20,
                CANCEL_SPRITES,
                button -> method_25419(),
                class_5244.field_39003
        ));
        cancelButton.method_47400(class_7919.method_47407(class_5244.field_24335));
    }

    private void loadPreview() {
        UUID animUuid = ImageChatStorage.storeAnimated(sendBytes, class_310.method_1551().method_1548().method_1676());
        if (animUuid != null) {
            previewUuid = animUuid;
            previewId = ImageChatStorage.getTextureId(animUuid);
            imageWidth = ImageChatStorage.getFrameWidth(animUuid);
            imageHeight = ImageChatStorage.getFrameHeight(animUuid);
        } else {
            try {
                class_1011 nativeImage = class_1011.method_4309(new ByteArrayInputStream(previewBytes));
                imageWidth = nativeImage.method_4307();
                imageHeight = nativeImage.method_4323();
                previewTexture = new class_1043(() -> "chat_images_preview", nativeImage);
                previewId = class_2960.method_60655(Chat_images.MOD_ID, "preview_" + UUID.randomUUID().toString().replace("-", ""));
                class_310.method_1551().method_1531().method_4616(previewId, previewTexture);
                previewTexture.method_4524();
            } catch (IOException e) {
                Chat_images.LOGGER.error("Failed to load preview", e);
            }
        }
    }

    private void sendFile() {
        int offset = 0;
        while (offset < sendBytes.length) {
            int chunkSize = Math.min(ImageDataC2SPayload.MAX_CHUNK_SIZE, sendBytes.length - offset);
            byte[] chunk = new byte[chunkSize];
            System.arraycopy(sendBytes, offset, chunk, 0, chunkSize);
            offset += chunkSize;
            ClientPlayNetworking.send(new ImageDataC2SPayload(chunk));
        }
        ClientPlayNetworking.send(new ImageEndC2SPayload(sendBytes.length));

        if (isImage) {
            UUID imageId = previewUuid;
            if (imageId == null) {
                imageId = ImageChatStorage.storeAnimated(sendBytes, class_310.method_1551().method_1548().method_1676());
                if (imageId == null) {
                    imageId = ImageChatStorage.store(previewBytes, class_310.method_1551().method_1548().method_1676());
                }
            }
            if (imageId != null) {
                class_310 minecraft = class_310.method_1551();
                if (minecraft.field_1705 != null) {
                    minecraft.field_1705.method_1743().method_44811(
                            class_2561.method_43470("<" + class_310.method_1551().method_1548().method_1676() + ">"),
                            null,
                            new class_7591(0, null, null, "ChatImages#" + imageId)
                    );
                }
            }
        } else {
            class_310 minecraft = class_310.method_1551();
            String ext = FileUtil.getExtension(fileName);
            UUID fileId = FileChatStorage.store(sendBytes, fileName, class_310.method_1551().method_1548().method_1676());
            int iconColor = FileUtil.isVideo(ext) ? 0xFF4488FF : FileUtil.isAudio(ext) ? 0xFF44FF44 : 0xFF888888;
            class_1011 icon = new class_1011(16, 16, false);
            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 16; x++) {
                    icon.method_61941(x, y, iconColor);
                }
            }
            String suffix = fileId.toString().replace("-", "");
            class_1043 tex = new class_1043(() -> "chat_file_" + suffix, icon);
            class_2960 texId = class_2960.method_60655(Chat_images.MOD_ID, "file/" + suffix);
            minecraft.method_1531().method_4616(texId, tex);
            tex.method_4524();
            ImageChatStorage.storeTexture(fileId, tex, texId, class_310.method_1551().method_1548().method_1676());
            if (minecraft.field_1705 != null) {
                minecraft.field_1705.method_1743().method_44811(
                        class_2561.method_43470("<" + class_310.method_1551().method_1548().method_1676() + ">"),
                        null,
                        new class_7591(0, null, null, "ChatImages#" + fileId)
                );
            }
        }

        confirmed = true;
        method_25419();
    }

    @Override
    public boolean method_25402(class_11909 event, boolean isHovered) {
        if (super.method_25402(event, isHovered)) return true;
        if (!isImage) return true;
        if (event.method_74245() == 0 && previewId != null) {
            dragging = true;
            dragStartX = event.comp_4798();
            dragStartY = event.comp_4799();
            dragOffsetX = offsetX;
            dragOffsetY = offsetY;
        }
        if (event.method_74245() == 1) {
            method_25419();
        }
        return true;
    }

    @Override
    public boolean method_25406(class_11909 event) {
        dragging = false;
        if (super.method_25406(event)) return true;
        if (event.method_74245() == 1) {
            method_25419();
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (super.method_25403(event, dragX, dragY)) return true;
        if (dragging && event.method_74245() == 0) {
            offsetX = dragOffsetX + (event.comp_4798() - dragStartX);
            offsetY = dragOffsetY + (event.comp_4799() - dragStartY);
        }
        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!isImage || previewId == null) return true;
        double factor = scrollY > 0 ? 1.1 : 1.0 / 1.1;
        double newZoom = Math.max(0.025, Math.min(zoom * factor, 40.0));
        if (newZoom == zoom) return true;

        double fitScale = Math.min((double) field_22789 / imageWidth, (double) field_22790 / imageHeight) * 0.85;
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;
        double fracX = (mouseX - (cx - imageWidth * fitScale * zoom / 2 + offsetX)) / (imageWidth * fitScale * zoom);
        double fracY = (mouseY - (cy - imageHeight * fitScale * zoom / 2 + offsetY)) / (imageHeight * fitScale * zoom);
        zoom = newZoom;
        offsetX = mouseX - cx + imageWidth * fitScale * zoom * (0.5 - fracX);
        offsetY = mouseY - cy + imageHeight * fitScale * zoom * (0.5 - fracY);

        return true;
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (event.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            method_25419();
            return true;
        }
        if (event.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER || event.comp_4795() == org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER) {
            sendFile();
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
    }

    @Override
    protected void actualRender(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        super.actualRender(guiGraphics, mouseX, mouseY, delta);

        if (isImage) {
            renderImagePreview(guiGraphics, mouseX, mouseY, delta);
        } else {
            renderFileInfo(guiGraphics);
        }
    }

    private void renderImagePreview(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        if (previewId == null) {
            guiGraphics.method_27535(field_22793, class_2561.method_43471("chat_images.load_error"),
                    field_22789 / 2 - field_22793.method_27525(class_2561.method_43471("chat_images.load_error")) / 2,
                    field_22790 / 2, 0xFFFF5555);
            return;
        }

        double fitScale = Math.min((double) field_22789 / imageWidth, (double) field_22790 / imageHeight) * 0.85;
        int imgW = (int) (imageWidth * fitScale * zoom);
        int imgH = (int) (imageHeight * fitScale * zoom);
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;
        int x = cx - imgW / 2 + (int) offsetX;
        int y = cy - imgH / 2 + (int) offsetY;

        if (previewUuid != null && ImageChatStorage.getFrameCount(previewUuid) > 1) {
            int currentFrame = ImageChatStorage.getCurrentFrame(previewUuid);
            int frameCount = ImageChatStorage.getFrameCount(previewUuid);
            float vMin = (float) currentFrame / frameCount;
            float vMax = (float) (currentFrame + 1) / frameCount;
            guiGraphics.method_70845(previewId, x, y, x + imgW, y + imgH, 0.0f, 1.0f, vMin, vMax);
        } else {
            guiGraphics.method_70845(previewId, x, y, x + imgW, y + imgH, 0.0f, 1.0f, 0.0f, 1.0f);
        }

        String info = imageWidth + "x" + imageHeight + "  " + String.format("%.0f", zoom * 100) + "%";
        guiGraphics.method_25303(field_22793, info, 10, field_22790 - 20, 0xFFFFFFFF);
    }

    private void renderFileInfo(class_332 guiGraphics) {
        String ext = FileUtil.getExtension(fileName);
        String type = FileUtil.isVideo(ext) ? "Video" : FileUtil.isAudio(ext) ? "Audio" : "File";

        int cx = field_22789 / 2;
        int cy = field_22790 / 2 - 20;

        guiGraphics.method_27535(field_22793, class_2561.method_43470("§l" + fileName), cx - field_22793.method_1727(fileName) / 2, cy - 20, 0xFFFFFFFF);
        guiGraphics.method_27535(field_22793, class_2561.method_43470("Type: " + type + " (." + ext + ")"), cx - field_22793.method_1727("Type: " + type + " (." + ext + ")") / 2, cy + 5, 0xFFAAAAAA);
        guiGraphics.method_27535(field_22793, class_2561.method_43470("Size: " + FileUtil.formatFileSize(sendBytes.length)), cx - field_22793.method_1727("Size: " + FileUtil.formatFileSize(sendBytes.length)) / 2, cy + 20, 0xFFAAAAAA);
        guiGraphics.method_27535(field_22793, class_2561.method_43471("chat_images.confirm_hint"), cx - field_22793.method_27525(class_2561.method_43471("chat_images.confirm_hint")) / 2, cy + 45, 0xFF666666);
    }

    @Override
    public void method_25432() {
        super.method_25432();
        if (previewUuid != null) {
            if (!confirmed) {
                ImageChatStorage.remove(previewUuid);
            }
        } else {
            if (previewId != null) {
                class_310.method_1551().method_1531().method_4615(previewId);
            }
            if (previewTexture != null) {
                previewTexture.close();
            }
        }
    }
}
