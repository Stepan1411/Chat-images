package ru.stepan1411.chat_images.client;

import net.minecraft.class_332;

public final class ChatGraphicsHolder {
    private static class_332 current;

    public static void set(class_332 g) {
        current = g;
    }

    public static class_332 get() {
        return current;
    }

    private ChatGraphicsHolder() {}
}
