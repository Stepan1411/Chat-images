package ru.stepan1411.chat_images.client;

import ru.stepan1411.chat_images.Chat_images;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class ImageChatStorage {

    private static final Map<UUID, TextureEntry> TEXTURES = new ConcurrentHashMap<>();

    private record TextureEntry(class_1043 texture, class_2960 id, String senderName) {}

    public static UUID store(byte[] pngData, String senderName) {
        try {
            class_1011 nativeImage = class_1011.method_4309(new ByteArrayInputStream(pngData));
            String suffix = UUID.randomUUID().toString().replace("-", "");
            class_1043 texture = new class_1043(() -> "chat_image_" + suffix, nativeImage);
            UUID uuid = UUID.randomUUID();
            class_2960 id = class_2960.method_60655(Chat_images.MOD_ID, "dynamic/" + suffix);
            class_310.method_1551().method_1531().method_4616(id, texture);
            texture.method_4524();
            TEXTURES.put(uuid, new TextureEntry(texture, id, senderName));
            Chat_images.LOGGER.info("Stored image {} from {}, texture={}", uuid, senderName, texture.method_68004());
            return uuid;
        } catch (IOException e) {
            Chat_imagesClient.LOGGER.error("Failed to decode image", e);
            return null;
        }
    }

    public static void storeTexture(UUID uuid, class_1043 texture, class_2960 id, String senderName) {
        TEXTURES.put(uuid, new TextureEntry(texture, id, senderName));
    }

    public static class_2960 getTextureId(UUID id) {
        TextureEntry entry = TEXTURES.get(id);
        return entry != null ? entry.id : null;
    }

    public static class_1043 getTexture(UUID id) {
        TextureEntry entry = TEXTURES.get(id);
        return entry != null ? entry.texture : null;
    }

    public static String getSenderName(UUID id) {
        TextureEntry entry = TEXTURES.get(id);
        return entry != null ? entry.senderName : "Unknown";
    }

    public static void remove(UUID id) {
        TextureEntry entry = TEXTURES.remove(id);
        if (entry != null) {
            class_310.method_1551().method_1531().method_4615(entry.id);
            entry.texture.close();
        }
    }

    public static void clear() {
        class_310 mc = class_310.method_1551();
        TEXTURES.values().forEach(entry -> {
            mc.method_1531().method_4615(entry.id);
            entry.texture.close();
        });
        TEXTURES.clear();
    }

}
