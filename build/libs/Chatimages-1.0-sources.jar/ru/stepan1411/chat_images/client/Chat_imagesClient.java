package ru.stepan1411.chat_images.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7591;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.stepan1411.chat_images.Chat_images;
import ru.stepan1411.chat_images.networking.*;

import javax.imageio.ImageIO;
import java.util.*;

public class Chat_imagesClient implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("ChatImagesClient");

    public static boolean serverHasMod = false;

    private static final Map<UUID, List<byte[]>> PENDING_IMAGES = new HashMap<>();

    @Override
    public void onInitializeClient() {
        ImageIO.scanForPlugins();

        ClientPlayNetworking.registerGlobalReceiver(ImageDataS2CPayload.TYPE, (payload, context) -> {
            context.client().execute(() -> {
                PENDING_IMAGES.computeIfAbsent(payload.sender(), k -> new ArrayList<>()).add(payload.data());
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(ImageEndS2CPayload.TYPE, (payload, context) -> {
            context.client().execute(() -> {
                UUID senderUuid = payload.sender();
                String senderName = payload.senderName();
                int totalSize = payload.totalSize();

                List<byte[]> chunks = PENDING_IMAGES.remove(senderUuid);
                if (chunks == null || chunks.isEmpty()) return;

                byte[] fileData = new byte[totalSize];
                int offset = 0;
                for (byte[] chunk : chunks) {
                    System.arraycopy(chunk, 0, fileData, offset, chunk.length);
                    offset += chunk.length;
                }

                class_310 client = context.client();
                client.execute(() -> {
                    UUID imageId = ImageChatStorage.storeAnimated(fileData, senderName);
                    if (imageId == null) {
                        byte[] pngBytes = FileUtil.convertToPng(fileData);
                        if (pngBytes != null) {
                            imageId = ImageChatStorage.store(pngBytes, senderName);
                        } else {
                            String ext = FileUtil.getExtension(senderName.contains(".") ? senderName : "");
                            if (ext.isEmpty()) ext = "file";

                            UUID fileId = FileChatStorage.store(fileData, senderName, senderName);
                            int iconColor = FileUtil.isVideo(ext) ? 0xFF4488FF : FileUtil.isAudio(ext) ? 0xFF44FF44 : 0xFF888888;
                            class_1011 icon = new class_1011(16, 16, false);
                            for (int y = 0; y < 16; y++) {
                                for (int x = 0; x < 16; x++) {
                                    icon.method_61941(x, y, iconColor);
                                }
                            }
                            String suffix = fileId.toString().replace("-", "");
                            class_1043 tex = new class_1043(() -> "chat_file_" + suffix, icon);
                            class_2960 texId = class_2960.method_60655(Chat_images.MOD_ID, "file/" + suffix);
                            class_310.method_1551().method_1531().method_4616(texId, tex);
                            tex.method_4524();
                            ImageChatStorage.storeTexture(fileId, tex, texId, senderName);

                            if (client.field_1705 != null) {
                                client.field_1705.method_1743().method_44811(
                                        class_2561.method_43470("<" + senderName + ">"),
                                        null,
                                        new class_7591(0, null, null, "ChatImages#" + fileId)
                                );
                            }
                            return;
                        }
                    }
                    if (imageId != null && client.field_1705 != null) {
                        client.field_1705.method_1743().method_44811(
                                class_2561.method_43470("<" + senderName + ">"),
                                null,
                                new class_7591(0, null, null, "ChatImages#" + imageId)
                        );
                    }
                });
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(TestS2CPayload.TYPE, (payload, context) -> {
            context.client().execute(() -> {
                ClientPlayNetworking.send(new TestAckC2SPayload());
            });
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            PENDING_IMAGES.clear();
            serverHasMod = ClientPlayNetworking.canSend(ImageDataC2SPayload.TYPE.comp_2242());
            ClientPlayNetworking.send(new HandshakeC2SPayload());
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            serverHasMod = false;
            PENDING_IMAGES.clear();
        });
    }

}
