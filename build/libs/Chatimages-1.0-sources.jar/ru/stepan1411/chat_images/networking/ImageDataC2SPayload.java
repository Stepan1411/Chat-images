package ru.stepan1411.chat_images.networking;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import ru.stepan1411.chat_images.Chat_images;

public record ImageDataC2SPayload(byte[] data) implements class_8710 {

    public static final int MAX_CHUNK_SIZE = 30000;
    public static final class_9154<ImageDataC2SPayload> TYPE = new class_9154<>(Chat_images.id("image_data_c2s"));
    public static final class_9139<class_9129, ImageDataC2SPayload> STREAM_CODEC = class_9139.method_56434(
            class_9135.method_56895(MAX_CHUNK_SIZE),
            ImageDataC2SPayload::data,
            ImageDataC2SPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
