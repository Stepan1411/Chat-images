package ru.stepan1411.chat_images.networking;

import ru.stepan1411.chat_images.Chat_images;

import java.util.UUID;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ImageDataS2CPayload(UUID sender, byte[] data) implements class_8710 {

    public static final int MAX_CHUNK_SIZE = 100000;
    public static final class_9154<ImageDataS2CPayload> TYPE = new class_9154<>(Chat_images.id("image_data_s2c"));
    public static final class_9139<class_9129, ImageDataS2CPayload> STREAM_CODEC = class_9139.method_56435(
            class_4844.field_48453,
            ImageDataS2CPayload::sender,
            class_9135.method_56895(MAX_CHUNK_SIZE),
            ImageDataS2CPayload::data,
            ImageDataS2CPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
