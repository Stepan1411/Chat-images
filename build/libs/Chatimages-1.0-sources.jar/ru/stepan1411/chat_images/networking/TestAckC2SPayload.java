package ru.stepan1411.chat_images.networking;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import ru.stepan1411.chat_images.Chat_images;

public record TestAckC2SPayload() implements class_8710 {

    public static final class_9154<TestAckC2SPayload> TYPE = new class_9154<>(Chat_images.id("test_ack_c2s"));
    public static final class_9139<class_9129, TestAckC2SPayload> STREAM_CODEC = class_9139.method_56431(new TestAckC2SPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
