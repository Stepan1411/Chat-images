package ru.stepan1411.chat_images.networking;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import ru.stepan1411.chat_images.Chat_images;

public record ImageEndC2SPayload(int totalSize) implements class_8710 {

    public static final class_9154<ImageEndC2SPayload> TYPE = new class_9154<>(Chat_images.id("image_end_c2s"));
    public static final class_9139<class_9129, ImageEndC2SPayload> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48550,
            ImageEndC2SPayload::totalSize,
            ImageEndC2SPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
