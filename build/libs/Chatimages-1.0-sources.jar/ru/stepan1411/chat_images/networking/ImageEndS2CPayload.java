package ru.stepan1411.chat_images.networking;

import ru.stepan1411.chat_images.Chat_images;

import java.util.UUID;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ImageEndS2CPayload(UUID sender, String senderName, int totalSize) implements class_8710 {

    public static final class_9154<ImageEndS2CPayload> TYPE = new class_9154<>(Chat_images.id("image_end_s2c"));
    public static final class_9139<class_9129, ImageEndS2CPayload> STREAM_CODEC = class_9139.method_56436(
            class_4844.field_48453,
            ImageEndS2CPayload::sender,
            class_9135.method_56364(64),
            ImageEndS2CPayload::senderName,
            class_9135.field_48550,
            ImageEndS2CPayload::totalSize,
            ImageEndS2CPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
