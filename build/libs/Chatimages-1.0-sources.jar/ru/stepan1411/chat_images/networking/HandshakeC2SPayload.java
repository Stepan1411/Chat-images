package ru.stepan1411.chat_images.networking;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import ru.stepan1411.chat_images.Chat_images;

public record HandshakeC2SPayload() implements class_8710 {

    public static final class_9154<HandshakeC2SPayload> TYPE = new class_9154<>(Chat_images.id("handshake"));
    public static final class_9139<class_9129, HandshakeC2SPayload> STREAM_CODEC = class_9139.method_56431(new HandshakeC2SPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

}
