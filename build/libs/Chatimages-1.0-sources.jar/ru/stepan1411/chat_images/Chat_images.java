package ru.stepan1411.chat_images;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.stepan1411.chat_images.networking.*;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public class Chat_images implements ModInitializer {

    public static final String MOD_ID = "chat_images";
    public static final Logger LOGGER = LoggerFactory.getLogger("ChatImages");

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    private static final Set<UUID> MODDED_PLAYERS = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, List<byte[]>> PENDING_IMAGES = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> PENDING_TESTS = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(HandshakeC2SPayload.TYPE, HandshakeC2SPayload.STREAM_CODEC);
        PayloadTypeRegistry.playC2S().register(ImageDataC2SPayload.TYPE, ImageDataC2SPayload.STREAM_CODEC);
        PayloadTypeRegistry.playC2S().register(ImageEndC2SPayload.TYPE, ImageEndC2SPayload.STREAM_CODEC);
        PayloadTypeRegistry.playC2S().register(TestAckC2SPayload.TYPE, TestAckC2SPayload.STREAM_CODEC);
        PayloadTypeRegistry.playS2C().register(ImageDataS2CPayload.TYPE, ImageDataS2CPayload.STREAM_CODEC);
        PayloadTypeRegistry.playS2C().register(ImageEndS2CPayload.TYPE, ImageEndS2CPayload.STREAM_CODEC);
        PayloadTypeRegistry.playS2C().register(TestS2CPayload.TYPE, TestS2CPayload.STREAM_CODEC);

        ServerPlayNetworking.registerGlobalReceiver(HandshakeC2SPayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                MODDED_PLAYERS.add(player.method_5667());
                LOGGER.info("Player {} has ChatImages mod", player.method_7334().name());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(ImageDataC2SPayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                PENDING_IMAGES.computeIfAbsent(player.method_5667(), k -> Collections.synchronizedList(new ArrayList<>())).add(payload.data());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(ImageEndC2SPayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                int totalSize = payload.totalSize();
                List<byte[]> chunks = PENDING_IMAGES.remove(player.method_5667());
                if (chunks == null || chunks.isEmpty()) return;

                byte[] imageData = new byte[totalSize];
                int offset = 0;
                for (byte[] chunk : chunks) {
                    System.arraycopy(chunk, 0, imageData, offset, chunk.length);
                    offset += chunk.length;
                }

                broadcastImage(context.server(), player, imageData);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TestAckC2SPayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                MODDED_PLAYERS.add(player.method_5667());
                PENDING_TESTS.put(player.method_5667(), true);
            });
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID uuid = handler.method_32311().method_5667();
            MODDED_PLAYERS.remove(uuid);
            PENDING_IMAGES.remove(uuid);
            PENDING_TESTS.remove(uuid);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("chatimages")
                            .then(LiteralArgumentBuilder.<class_2168>literal("test")
                                    .then(RequiredArgumentBuilder.<class_2168, String>argument("player", StringArgumentType.word())
                                            .executes(this::executeTest)
                                    )
                            )
                            .then(LiteralArgumentBuilder.<class_2168>literal("reconnect")
                                    .then(RequiredArgumentBuilder.<class_2168, String>argument("player", StringArgumentType.word())
                                            .executes(this::executeReconnect)
                                    )
                            )
            );
        });
    }

    private int executeTest(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        String playerName = StringArgumentType.getString(context, "player");

        MinecraftServer server = source.method_9211();
        class_3222 target = server.method_3760().method_14566(playerName);

        if (target == null) {
            source.method_9213(class_2561.method_43470("Player not found: " + playerName));
            return 0;
        }

        UUID targetUuid = target.method_5667();

        if (MODDED_PLAYERS.contains(targetUuid)) {
            source.method_9226(() -> class_2561.method_43470("§a" + playerName + " has Chat Images (handshake confirmed)"), false);
            return Command.SINGLE_SUCCESS;
        }

        PENDING_TESTS.put(targetUuid, false);
        ServerPlayNetworking.send(target, new TestS2CPayload());

        source.method_9226(() -> class_2561.method_43470("§7Testing " + playerName + "..."), false);

        CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            server.execute(() -> {
                Boolean acked = PENDING_TESTS.remove(targetUuid);
                if (Boolean.TRUE.equals(acked)) {
                    source.method_9226(() -> class_2561.method_43470("§a" + playerName + " has Chat Images (test confirmed)"), false);
                    MODDED_PLAYERS.add(targetUuid);
                } else {
                    source.method_9213(class_2561.method_43470("§c" + playerName + " does not have Chat Images"));
                }
            });
        });

        return Command.SINGLE_SUCCESS;
    }

    private int executeReconnect(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        String playerName = StringArgumentType.getString(context, "player");

        MinecraftServer server = source.method_9211();
        class_3222 target = server.method_3760().method_14566(playerName);

        if (target == null) {
            source.method_9213(class_2561.method_43470("Player not found: " + playerName));
            return 0;
        }

        target.field_13987.method_52396(class_2561.method_43470("Reconnecting to apply Chat Images changes..."));
        source.method_9226(() -> class_2561.method_43470("§a" + playerName + " has been disconnected"), false);
        return Command.SINGLE_SUCCESS;
    }

    private static void broadcastImage(MinecraftServer server, class_3222 sender, byte[] imageData) {
        for (class_3222 player : server.method_3760().method_14571()) {
            if (player.method_5667().equals(sender.method_5667())) continue;

            if (MODDED_PLAYERS.contains(player.method_5667())) {
                sendImageToPlayer(player, sender.method_5667(), sender.method_7334().name(), imageData);
            } else {
                player.method_43502(class_2561.method_43470(
                        "§7[ChatImages] §f" + sender.method_7334().name() + " §7sent an image. Install ChatImages to view it"
                ), false);
            }
        }
    }

    private static void sendImageToPlayer(class_3222 player, UUID senderUuid, String senderName, byte[] imageData) {
        int offset = 0;
        while (offset < imageData.length) {
            int chunkSize = Math.min(ImageDataS2CPayload.MAX_CHUNK_SIZE, imageData.length - offset);
            byte[] chunk = new byte[chunkSize];
            System.arraycopy(imageData, offset, chunk, 0, chunkSize);
            offset += chunkSize;
            ServerPlayNetworking.send(player, new ImageDataS2CPayload(senderUuid, chunk));
        }
        ServerPlayNetworking.send(player, new ImageEndS2CPayload(senderUuid, senderName, imageData.length));
    }

}
