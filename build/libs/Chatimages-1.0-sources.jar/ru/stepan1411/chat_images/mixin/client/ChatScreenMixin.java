package ru.stepan1411.chat_images.mixin.client;

import org.lwjgl.PointerBuffer;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.util.tinyfd.TinyFileDialogs;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.stepan1411.chat_images.Chat_images;
import ru.stepan1411.chat_images.client.Chat_imagesClient;
import ru.stepan1411.chat_images.client.ClickableImageTracker;
import ru.stepan1411.chat_images.client.FileChatStorage;
import ru.stepan1411.chat_images.client.FileUtil;
import ru.stepan1411.chat_images.client.screen.FileViewerScreen;
import ru.stepan1411.chat_images.client.screen.FullScreenImageViewerScreen;
import ru.stepan1411.chat_images.client.screen.ImageConfirmScreen;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_344;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import net.minecraft.class_8666;
import org.lwjgl.system.MemoryStack;

@Mixin(class_408.class)
abstract class ChatScreenMixin extends class_437 {

    @Shadow
    protected class_342 input;

    @Unique
    private class_8666 chatImages_getButtonSprites() {
        if (Chat_imagesClient.serverHasMod) {
            return new class_8666(
                    class_2960.method_60655(Chat_images.MOD_ID, "chat_button"),
                    class_2960.method_60655(Chat_images.MOD_ID, "chat_button_hovered")
            );
        }
        class_2960 error = class_2960.method_60655(Chat_images.MOD_ID, "chat_button_error");
        return new class_8666(error, error, error);
    }

    @Unique
    private class_344 chatImages_button;

    @Unique
    private static Long chatImages_handCursor;

    private ChatScreenMixin() {
        super(null);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void chatImages_initTail(CallbackInfo ci) {
        int x = input.method_46426();
        int y = input.method_46427();
        chatImages_button = method_37063(new class_344(
                x - 3,
                y - 3,
                14,
                14,
                chatImages_getButtonSprites(),
                button -> openFileChooser()
        ));
        chatImages_button.method_47400(class_7919.method_47407(class_2561.method_43471(
                Chat_imagesClient.serverHasMod ? "chat_images.send_image" : "chat_images.server_not_supported"
        )));
        chatImages_button.field_22763 = Chat_imagesClient.serverHasMod;
        input.method_25358(input.method_25368() - 14);
        input.method_46421(x + 14);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void chatImages_renderHead(class_332 guiGraphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        boolean onImage = false;
        for (var area : ClickableImageTracker.getClickable()) {
            if (mouseX >= area.x() && mouseX <= area.x() + area.w()
                    && mouseY >= area.y() && mouseY <= area.y() + area.h()) {
                onImage = true;
                break;
            }
        }
        long window = class_310.method_1551().method_22683().method_4490();
        if (onImage) {
            if (chatImages_handCursor == null) {
                chatImages_handCursor = GLFW.glfwCreateStandardCursor(GLFW.GLFW_HAND_CURSOR);
            }
            GLFW.glfwSetCursor(window, chatImages_handCursor);
        } else {
            GLFW.glfwSetCursor(window, 0);
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void chatImages_mouseClicked(class_11909 event, boolean isHovered, CallbackInfoReturnable<Boolean> cir) {
        if (event.method_74245() == 0) {
            for (var area : ClickableImageTracker.getClickable()) {
                if (event.comp_4798() >= area.x() && event.comp_4798() <= area.x() + area.w()
                        && event.comp_4799() >= area.y() && event.comp_4799() <= area.y() + area.h()) {
                    class_310 mc = class_310.method_1551();
                    if (FileChatStorage.get(area.imageId()) != null) {
                        mc.method_1507(new FileViewerScreen(mc.field_1755, area.imageId()));
                    } else {
                        mc.method_1507(new FullScreenImageViewerScreen(mc.field_1755, area.imageId()));
                    }
                    cir.setReturnValue(true);
                    return;
                }
            }
        }
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void chatImages_removed(CallbackInfo ci) {
        if (chatImages_handCursor != null) {
            GLFW.glfwSetCursor(class_310.method_1551().method_22683().method_4490(), 0);
        }
    }

    @Unique
    private void openFileChooser() {
        if (!Chat_imagesClient.serverHasMod) return;
        new Thread(() -> {
            try (MemoryStack stack = MemoryStack.stackPush()) {
                PointerBuffer filterPatterns = stack.mallocPointer(3);
                filterPatterns.put(stack.UTF8("*.png;*.jpg;*.jpeg;*.webp;*.jfif;*.pjpeg;*.gif"));
                filterPatterns.put(stack.UTF8("*.mp3;*.mkv;*.mov"));
                filterPatterns.put(stack.UTF8("*.png;*.jpg;*.jpeg;*.webp;*.jfif;*.pjpeg;*.gif;*.mp3;*.mkv;*.mov"));
                filterPatterns.flip();
                String result = TinyFileDialogs.tinyfd_openFileDialog(
                        class_2561.method_43471("chat_images.select_file").getString(),
                        null,
                        filterPatterns,
                        "Multimedia files",
                        false
                );
                if (result != null) {
                    String fileName = FileUtil.fileNameFromPath(result);
                    byte[] fileBytes = Files.readAllBytes(new File(result).toPath());
                    String ext = FileUtil.getExtension(fileName);

                    if (FileUtil.isImage(ext)) {
                        byte[] pngBytes = FileUtil.convertToPng(fileBytes);
                        if (pngBytes == null) {
                            field_22787.execute(() -> field_22787.field_1724.method_7353(class_2561.method_43470("§c[ChatImages] Unsupported image format"), true));
                            return;
                        }
                        final byte[] sendBytes = fileBytes;
                        final byte[] previewBytes = pngBytes;
                        field_22787.execute(() ->
                                field_22787.method_1507(new ImageConfirmScreen(this, sendBytes, previewBytes, fileName, true)));
                    } else {
                        field_22787.execute(() ->
                                field_22787.field_1724.method_7353(class_2561.method_43470("§e[ChatImages] Video/audio support is under development"), true));
                    }
                }
            } catch (IOException e) {
                Chat_images.LOGGER.error("Failed to read file", e);
            }
        }).start();
    }

}
